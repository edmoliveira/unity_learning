using Document.Management.Business.Infrastructure.Helpers;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace Document.Management.Api
{
    /// <summary>
    /// Startup
    /// </summary>
    public class Startup
    {
        #region Fields private

        /// <summary>
        /// Web Api version
        /// </summary>
        private readonly Version _apiVersion = new Version(1, 0);
        /// <summary>
        /// Allow specific origins.
        /// </summary>
        private readonly string _allowSpecificOrigins = "allowSpecificOrigins";
        /// <summary>
        /// Represents a set of key/value application configuration properties.
        /// </summary>
        private readonly IConfiguration _configuration;

        #endregion

        #region Consctructors

        /// <summary>
        /// Initializes a new instance of the Machine.Food.WebApi.Startup class.
        /// </summary>
        /// <param name="configuration">Represents a set of key/value application configuration properties.</param>
        public Startup(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        #endregion

        #region Methods public

        /// <summary>
        /// This method gets called by the runtime. Use this method to add services to the container.
        /// </summary>
        /// <param name="services">Specifies the contract for a collection of service descriptors.</param>
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDependencyGroup(_configuration, _allowSpecificOrigins, _apiVersion, typeof(Startup));
        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        /// </summary>
        /// <param name="app">Defines a class that provides the mechanisms to configure an application's request pipeline.</param>
        /// <param name="env">Provides information about the web hosting environment an application is running in.</param>
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseGroup(_configuration, env, _allowSpecificOrigins);
        }

        #endregion
    }
}
