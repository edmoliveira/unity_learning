﻿using Document.Management.Business.Applications.User;
using Document.Management.Business.Infrastructure;
using Document.Management.Business.Infrastructure.Helpers.Attributes;
using Document.Management.Business.Infrastructure.Helpers.Controllers;
using Document.Management.Business.Infrastructure.Helpers.Extensions;
using Document.Management.Business.Infrastructure.Helpers.Filters;
using Document.Management.Business.Models.User;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Swashbuckle.AspNetCore.Annotations;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace Document.Management.Api.Controllers.Users
{
    /// <summary>
    /// User CRUD.
    /// </summary>
    [ApiController]
    [RequireHttps]
    [Produces("application/json")]
    [Route("api/users")]
    [SerialNumberAuthorizationFilter]
    [AuthorizeRoles(UserRole.Admin)]
    public sealed class UsersController : CustomControllerBase
    {
        #region Fields private

        /// <summary>
        /// Managing of the user.
        /// </summary>
        private readonly IUserApplication _application;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the Document.Management.Api.Controllers.Users.UsersControllers class.
        /// </summary>
        /// <param name="application">Managing of the user.</param>
        /// <param name="logger">Log</param>
        public UsersController(IUserApplication application, ILogger<UsersController> logger) : base(logger)
        {
            _application = application;
        }

        #endregion

        #region Method public

        /// <summary>
        /// Gets the user by id.
        /// </summary>
        /// <param name="id">User id</param>
        /// <returns>UserResponse</returns>
        [ApiExplorerSettings(GroupName = "Users")]
        [HttpGet()]
        [ApiVersion("1.0")]
        [Route("{id}/{v:apiVersion}")]
        [TypeFilter(typeof(LogFilterAttribute))]
        [ProducesResponseType(typeof(UserResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [SwaggerOperation(
            Summary = "Get User",
            Description = "Gets the user by id."
        )]
        public async Task<IActionResult> GetAsync([Required] long id)
        {
            return await TryActionResultAsync(async stopwatch =>
            {
                string methodName = nameof(GetAsync);

                _Logger.LogInformation(GetMethodBeginMessage(methodName));

                _Logger.DebugIsEnabled(() => string.Concat("Request: ", id));

                UserResponse response = await _application.GetAsync(id).ConfigureAwait(false);

                _Logger.DebugIsEnabled(() => string.Concat("Response: ", JsonConvert.SerializeObject(response)));

                _Logger.LogInformation(GetMethodEndMessage(methodName, stopwatch.StopAndGetMilliseconds()));

                return Ok(response);
            }).ConfigureAwait(false);
        }

        /// <summary>
        /// Gets all registered users.
        /// </summary>
        /// <returns>SignInResponse</returns>
        [ApiExplorerSettings(GroupName = "Users")]
        [HttpGet()]
        [ApiVersion("1.0")]
        [Route("{v:apiVersion}")]
        [TypeFilter(typeof(LogFilterAttribute))]
        [ProducesResponseType(typeof(List<UserResponse>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [SwaggerOperation(
            Summary = "Get All Users",
            Description = "Gets all registered users."
        )]
        public async Task<IActionResult> GetAllAsync()
        {
            return await TryActionResultAsync(async stopwatch =>
            {
                string methodName = nameof(GetAllAsync);

                _Logger.LogInformation(GetMethodBeginMessage(methodName));

                List<UserResponse> response = await _application.GetAllAsync().ConfigureAwait(false);

                _Logger.DebugIsEnabled(() => string.Concat("Response: ", JsonConvert.SerializeObject(response)));

                _Logger.LogInformation(GetMethodEndMessage(methodName, stopwatch.StopAndGetMilliseconds()));

                return Ok(response);
            }).ConfigureAwait(false);
        }

        /// <summary>
        /// Registers an user.
        /// </summary>
        /// <param name="request">Request data</param>
        /// <returns>UserResponse</returns>
        [ApiExplorerSettings(GroupName = "Users")]
        [HttpPost()]
        [ApiVersion("1.0")]
        [Route("{v:apiVersion}")]
        [TypeFilter(typeof(LogFilterAttribute))]
        [ProducesResponseType(typeof(UserResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [SwaggerOperation(
            Summary = "Add User",
            Description = "Registers an user."
        )]
        public async Task<IActionResult> AddAsync([BindRequired] UserAddRequest request)
        {
            return await TryActionResultAsync(async stopwatch =>
            {
                string methodName = nameof(AddAsync);

                _Logger.LogInformation(GetMethodBeginMessage(methodName));

                _Logger.DebugIsEnabled(() => string.Concat("Request: ", JsonConvert.SerializeObject(request)));

                UserResponse response = await _application.AddAsync(request).ConfigureAwait(false);

                _Logger.DebugIsEnabled(() => string.Concat("Response: ", JsonConvert.SerializeObject(response)));

                _Logger.LogInformation(GetMethodEndMessage(methodName, stopwatch.StopAndGetMilliseconds()));

                return Ok(response);
            }).ConfigureAwait(false);
        }

        /// <summary>
        /// Updates an user data.
        /// </summary>
        /// <param name="request">Request data</param>
        [ApiExplorerSettings(GroupName = "Users")]
        [HttpPut()]
        [ApiVersion("1.0")]
        [Route("{v:apiVersion}")]
        [TypeFilter(typeof(LogFilterAttribute))]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [SwaggerOperation(
            Summary = "Update User",
            Description = "Updates an user data."
        )]
        public async Task<IActionResult> UpdateAsync([BindRequired] UserUpdateRequest request)
        {
            return await TryActionResultAsync(async stopwatch =>
            {
                string methodName = nameof(UpdateAsync);

                _Logger.LogInformation(GetMethodBeginMessage(methodName));

                _Logger.DebugIsEnabled(() => string.Concat("Request: ", JsonConvert.SerializeObject(request)));

                _ = await _application.UpdateAsync(request).ConfigureAwait(false);

                _Logger.LogInformation(GetMethodEndMessage(methodName, stopwatch.StopAndGetMilliseconds()));

                return Ok();
            }).ConfigureAwait(false);
        }

        /// <summary>
        /// Removes an user.
        /// </summary>
        /// <param name="id">User id</param>
        [ApiExplorerSettings(GroupName = "Users")]
        [HttpDelete()]
        [ApiVersion("1.0")]
        [Route("{id}/{v:apiVersion}")]
        [TypeFilter(typeof(LogFilterAttribute))]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [SwaggerOperation(
            Summary = "Remove User",
            Description = "Removes an user."
        )]
        public async Task<IActionResult> RemoveAsync([Required] long id)
        {
            return await TryActionResultAsync(async stopwatch =>
            {
                string methodName = nameof(RemoveAsync);

                _Logger.LogInformation(GetMethodBeginMessage(methodName));

                _Logger.DebugIsEnabled(() => string.Concat("Request: ", id));

                await _application.RemoveAsync(id).ConfigureAwait(false);

                _Logger.LogInformation(GetMethodEndMessage(methodName, stopwatch.StopAndGetMilliseconds()));

                return Ok();
            }).ConfigureAwait(false);
        }

        #endregion
    }
}

