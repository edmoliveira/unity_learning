﻿using Document.Management.Business.Applications.User;
using Document.Management.Business.Infrastructure.Helpers.Controllers;
using Document.Management.Business.Infrastructure.Helpers.Extensions;
using Document.Management.Business.Infrastructure.Helpers.Filters;
using Document.Management.Business.Models.User;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Swashbuckle.AspNetCore.Annotations;
using System.Threading.Tasks;

namespace Document.Management.Api.Controllers.Users
{
    /// <summary>
    /// User CRUD.
    /// </summary>
    [ApiController]
    [RequireHttps]
    [Produces("application/json")]
    [Route("api/users/actions")]
    [SerialNumberAuthorizationFilter]
    public sealed class ActionsController : CustomControllerBase
    {
        #region Fields private

        /// <summary>
        /// Managing of the user.
        /// </summary>
        private readonly IUserApplication _application;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the Document.Management.Api.Controllers.Users.ActionsController class.
        /// </summary>
        /// <param name="application">Managing of the user.</param>
        /// <param name="logger">Log</param>
        public ActionsController(IUserApplication application, ILogger<UsersController> logger) : base(logger)
        {
            _application = application;
        }

        #endregion

        #region Method public

        /// <summary>
        /// Changes user password.
        /// </summary>
        /// <param name="request">Request data</param>
        /// <returns>UserResponse</returns>
        [ApiExplorerSettings(GroupName = "Users")]
        [HttpPost()]
        [ApiVersion("1.0")]
        [Route("change-password/{v:apiVersion}")]
        [Authorize]
        [TypeFilter(typeof(LogFilterAttribute))]
        [ProducesResponseType(typeof(ChangePasswordResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [SwaggerOperation(
            Summary = "Change Password",
            Description = "Changes user password."
        )]
        public async Task<IActionResult> ChangePasswordAsync([BindRequired] ChangePasswordRequest request)
        {
            return await TryActionResultAsync(async stopwatch =>
            {
                string methodName = nameof(ChangePasswordAsync);

                _Logger.LogInformation(GetMethodBeginMessage(methodName));

                _Logger.DebugIsEnabled(() => string.Concat("Request: ", JsonConvert.SerializeObject(request)));

                ChangePasswordResponse response = await _application.ChangePasswordAsync(request).ConfigureAwait(false);

                _Logger.DebugIsEnabled(() => string.Concat("Response: ", JsonConvert.SerializeObject(response)));

                _Logger.LogInformation(GetMethodEndMessage(methodName, stopwatch.StopAndGetMilliseconds()));

                return Ok(response);
            }).ConfigureAwait(false);
        }

        #endregion
    }
}

