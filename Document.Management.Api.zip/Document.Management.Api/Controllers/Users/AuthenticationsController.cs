﻿using Document.Management.Business.Applications.User;
using Document.Management.Business.Infrastructure.Helpers.Controllers;
using Document.Management.Business.Infrastructure.Helpers.Extensions;
using Document.Management.Business.Infrastructure.Helpers.Filters;
using Document.Management.Business.Models.User;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Swashbuckle.AspNetCore.Annotations;
using System.Threading.Tasks;

namespace Document.Management.Api.Controllers.Users
{
    /// <summary>
    /// Authenticate the user on the platform.
    /// </summary>
    [ApiController]
    [RequireHttps]
    [Produces("application/json")]
    [Route("api/users/authentications")]
    [SerialNumberAuthorizationFilter]
    public sealed class AuthenticationsController : CustomControllerBase
    {
        #region Fields private

        /// <summary>
        /// Managing of the user account.
        /// </summary>
        private readonly IAuthenticationApplication _application;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the Document.Management.Api.Controllers.Users.AuthenticationsController class.
        /// </summary>
        /// <param name="application">Managing of the user account.</param>
        /// <param name="logger">Log</param>
        public AuthenticationsController(IAuthenticationApplication application, ILogger<AuthenticationsController> logger) : base(logger)
        {
            _application = application;
        }

        #endregion

        #region Method public

        /// <summary>
        /// Login to the platform with credentials.
        /// </summary>
        /// <param name="request">Request data</param>
        /// <returns>SignInResponse</returns>
        [AllowAnonymous]
        [ApiExplorerSettings(GroupName = "Users")]
        [HttpPost()]
        [ApiVersion("1.0")]
        [Route("sign-in/{v:apiVersion}")]
        [TypeFilter(typeof(LogFilterAttribute))]
        [ProducesResponseType(typeof(AuthenticateResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [SwaggerOperation(
            Summary = "Sign In",
            Description = "Login to the platform with credentials."
        )]
        public async Task<IActionResult> SignInAsync([BindRequired] AuthenticateRequest request)
        {
            return await TryActionResultAsync(async stopwatch =>
            {
                string methodName = nameof(SignInAsync);

                _Logger.LogInformation(GetMethodBeginMessage(methodName));

                _Logger.DebugIsEnabled(() => string.Concat("Request: ", JsonConvert.SerializeObject(request)));

                AuthenticateResponse response = await _application.AuthenticateAsync(request).ConfigureAwait(false);

                _Logger.DebugIsEnabled(() => string.Concat("Response: ", JsonConvert.SerializeObject(response)));

                _Logger.LogInformation(GetMethodEndMessage(methodName, stopwatch.StopAndGetMilliseconds()));

                return Ok(response);
            }).ConfigureAwait(false);
        }

        /// <summary>
        /// Saves the user session when it is Windows Authentication..
        /// </summary>
        /// <returns>UserSessionResponse</returns>
        [AllowAnonymous]
        [ApiExplorerSettings(GroupName = "Users")]
        [HttpPost()]
        [ApiVersion("1.0")]
        [Route("save-user-session/{v:apiVersion}")]
        [TypeFilter(typeof(LogFilterAttribute))]
        [ProducesResponseType(typeof(UserSessionResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [SwaggerOperation(
            Summary = "Save User Session",
            Description = "Saves the user session when it is Windows Authentication."
        )]
        public async Task<IActionResult> SaveUserSessionAsync()
        {
            return await TryActionResultAsync(async stopwatch =>
            {
                string methodName = nameof(SaveUserSessionAsync);

                _Logger.LogInformation(GetMethodBeginMessage(methodName));

                UserSessionResponse response = await _application.SaveUserSessionAsync().ConfigureAwait(false);

                _Logger.DebugIsEnabled(() => string.Concat("Response: ", JsonConvert.SerializeObject(response)));

                _Logger.LogInformation(GetMethodEndMessage(methodName, stopwatch.StopAndGetMilliseconds()));

                return Ok(response);
            }).ConfigureAwait(false);
        }

        #endregion
    }
}
